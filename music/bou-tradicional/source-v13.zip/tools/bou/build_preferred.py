"""Marc's selected form (v1), with score-tempo entrance and a gentler common voice family."""
import hashlib
import json
import subprocess
import numpy as np
import soundfile as sf
from build_score_arrangement import ROOT, SR, build_events, dynamic, write_midi
from score_festive import tempo_at
from score_groove import groove
from preferred_production import percussion_shape, produce
from synth import additive, adsr, hz, put

OUT=ROOT/'output/bou-music/preferred'
ORDER=[*range(1,17),*range(18,46),47,*range(60,93)]

def preferred_tempo(bar,local):
    if bar<=18: return 120
    if bar==92: return 100  # Four written beats, 2.4 seconds instead of 6.4.
    return tempo_at(bar,local)


def voices(events,count):
    stems=[np.zeros((count,2),dtype=np.float32) for _ in range(3)]
    for e in events:
        v=e['voice'];dur=round(e['end']-e['start'],9)
        final=e['sourceBar']==92
        amp=(.36,.075,.08)[v]*dynamic(e['sourceBar'])
        if e['chord']: amp*=.32
        # Same instrument on every note, including the final C; only its volume fades.
        layers=((0,0,1),(7,-.5,.3),(-7,.5,.3)) if v==0 else ((0,(0,.3,-.2)[v],1),)
        for detune,pan,gain in layers:
            length=dur+.10
            wave,t=additive(hz(e['pitch']),length,1.35,.35,detune,
                            .004 if e['beats']>=2 else 0,fmax=9000)
            env=adsr(t,length,.01,.12,.80,.25)
            if final:env*=np.clip((dur-t)/(dur-.12),0,1)
            if e['sourceBar'] in (1,2,5,6) and e['beats']==2:
                env*=np.linspace(.55,1.1,len(env))
            put(stems[v],e['start'],wave*env*amp*gain,pan)
    return stems


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    score=json.loads((ROOT/'music/bou-score.json').read_text())
    events,bars,tempos,seconds=build_events({**score,'order':ORDER},festive=True,
                                         tempo_fn=preferred_tempo,intro_end_bpm=120)
    count=round((seconds[-1]+2)*SR)
    lead,second,bass=voices(events,count)
    drums,acc,percussion=groove(events,bars,seconds,festive=True,club=True,natural=True,club_start_bar=27,hit_shape=percussion_shape(bars),refined_ending=True)
    assert not percussion['pitched'] and not np.any(acc)
    trio=lead+second+bass
    mix,production=produce(trio,drums,events)
    gain=json.loads((ROOT/'output/bou-music/phrase-lab/manifest.json').read_text())['gain']
    files={}
    for name,arr in [('bou',mix),('melodia',lead),('tres-veus',trio)]:
        audio=arr if name=='bou' else arr*gain;wav=OUT/(name+'.wav')
        sf.write(wav,audio,SR,subtype='PCM_24')
        subprocess.run(['ffmpeg','-y','-v','error','-i',str(wav),'-codec:a','libmp3lame','-b:a','192k',str(wav.with_suffix('.mp3'))],check=True)
        files[name]=name+'.mp3?v='+hashlib.sha256(wav.with_suffix('.mp3').read_bytes()).hexdigest()[:12]
    write_midi(OUT/'bou.mid',events,tempos,percussion=percussion['hits'])
    manifest=dict(revision=13,selectedForm='v1',order=ORDER,duration=count/SR,musicEnd=float(seconds[-1]),
                  finalNoteSeconds=2.4,melodyStart=bars[0]['time'],events=events,bars=bars,
                  audio=files,masterGain=gain,percussion=percussion,listeningVerified=False,
                  clubStartSeconds=next(b['time'] for b in bars if b['sourceBar']==27),
                  production=production,voiceGains=[.36,.075,.08],
                  mix='Mulassa lead and hall/glue; audible secondary voices; kick-free opening; contrasting phrases and techno finale')
    (OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in manifest.items() if k not in ('events','bars','percussion')},indent=2))

if __name__=='__main__':main()
