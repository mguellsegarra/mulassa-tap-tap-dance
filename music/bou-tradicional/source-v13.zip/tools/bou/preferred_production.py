"""Phrase-based percussion contrast and the Mulassa-style hall/glue for the Bou trial."""
import numpy as np
from scipy.signal import fftconvolve
from synth import SR, glock, note_gate, hz, put, lp


def percussion_shape(bars):
    def shape(kind, beat, velocity, pan):
        bar=next((b for b in reversed(bars) if b['beat']<=beat),None)
        number=bar['sourceBar'] if bar else 0
        local=beat-bar['beat'] if bar else beat
        # Opening has sticks/timbals, no bass drum and no low taiko thump.
        if number<27 and kind in ('kick','technoKick'):
            return None
        if number<9:
            if kind=='don':kind,velocity='tim',velocity*.45
            elif kind in ('ka','snare','tim'):velocity*=.65
            elif kind=='crash':velocity*=.45
        elif number<19:
            if kind=='don':velocity*=.55
            if kind in ('ohat','clap') and number%4<2:return None
            if kind in ('shaker','tamb'):velocity*=.60
        elif number<27:
            if kind=='don':velocity*=.70
            if kind in ('shaker','ohat'):velocity*=.75
        # Contrasting statements and answers; save full four-on-the-floor for the coda.
        elif number<64:
            if kind=='technoKick':
                if number in (35,36,43,44) and local not in (0,2):return None
                velocity*=.60 if number<31 else .78
            if kind in ('hat','shaker') and number%4 in (0,1):velocity*=.65
        elif number<72:
            if kind=='kick':return None
            if kind=='don':velocity*=.65
        elif number<84:
            if kind=='technoKick':velocity*=.95
        else:
            if kind=='technoKick':velocity*=1.12
            if kind in ('tim','snare','tamb'):velocity*=1.10
        return kind,velocity,pan
    return shape


def produce(trio, drums, events):
    bell=np.zeros_like(trio)
    # Short score-note sparkles, never an undamped bell over the following pitch.
    for e in events:
        bar=e['sourceBar']
        if e['voice'] or e['chord'] or bar==92:continue
        if not (31<=bar<=47 or 72<=bar<=91):continue
        if abs(e['beat']-round(e['beat']))>1e-8:continue
        duration=min(.22,e['end']-e['start'])
        gain=.035 if bar<72 else .055
        put(bell,e['start'],note_gate(glock(hz(e['pitch'])),duration)*gain,.25)
    dry=trio+drums+bell
    # Same small-hall recipe as Mulassa, deterministic local noise.
    t=np.arange(int(1.6*SR))/SR;rng=np.random.default_rng(37)
    ir=np.stack([lp(rng.standard_normal(len(t)),.6)*np.exp(-t/.35) for _ in range(2)],1)
    ir[:int(.02*SR)]=0
    ir/=np.abs(ir).sum(0)**.5*12
    send=trio*(.30/.36)+drums*.10+bell*.3
    wet=np.stack([fftconvolve(send[:,c],ir[:,c])[:len(dry)] for c in range(2)],1)
    mix=dry+wet*.5
    # Mulassa's gentle nonlinear glue, capped below full scale.
    peak=float(abs(mix).max());drive=.98/peak
    mix=np.tanh(mix*drive*1.6)/np.tanh(1.6)*.76
    mix[-SR:]*=np.linspace(1,0,SR)[:,None]
    return mix,dict(hallSeconds=1.6,saturationDrive=1.6,preSaturationGain=drive)
