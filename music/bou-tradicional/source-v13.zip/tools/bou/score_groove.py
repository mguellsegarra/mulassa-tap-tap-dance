"""Festive percussion and short, score-derived accompaniment for the Bou.

Accompaniment only rearticulates pitches currently present in the written voices.
It never substitutes another melody or a guessed chord sequence.
"""
import numpy as np
from score_festive import energy_at, fast_repeat
from synth import SR, adsr, brass, hz, nylon, note_gate, perc, put

# Sixteenth-note grids over a complete 4/4 bar; x = accent, o = light hit.
PATTERNS = {
    'opening': dict(kick='x.......x.......', shaker='..o...o...o...o.'),
    'dance': dict(kick='x...x...x...x...', snare='....o.......o...',
                  clap='....x.......x...', shaker='oxoxoxoxoxoxoxox',
                  ohat='..o...o...o...o.', tim='......o.......o.'),
    'festa': dict(kick='x...x...x...x.o.', snare='....x.......x.o.',
                  clap='....x.......x...', hat='o.o.o.o.o.o.o.o.',
                  shaker='oxoxoxoxoxoxoxox', tamb='..o...x...o...x.',
                  tim='......o.......o.'),
    'final': dict(kick='x...x...x.o.x...', snare='....x.......x.o.',
                  clap='....x.......x...', hat='x.o.x.o.x.o.x.o.',
                  shaker='oxoxoxoxoxoxoxox', tamb='..x...x...x...x.',
                  tim='......o.......o.'),
}
LEVEL = dict(kick=.34,snare=.24,clap=.23,hat=.26,ohat=.20,
             shaker=.34,tamb=.25,tim=.20)



# Tight electronic kick: short pitch drop, rounded saturation, controlled sub tail.
# Local to this arrangement; the shared Mulassa/Drac instrument stays untouched.
_t = np.arange(round(.65*SR))/SR
_frequency = 48+105*np.exp(-_t/.022)
_body = np.sin(2*np.pi*np.cumsum(_frequency)/SR)*np.exp(-_t/.17)
_TECHNO_KICK = np.tanh(_body*2.1)/2.1
_TECHNO_KICK *= np.minimum(1,_t/.0015)*np.clip((.65-_t)/.025,0,1)

# Audible punch on phone speakers as well as sub bass; no extra pitched harmony.
_CLUB_KICK = (_TECHNO_KICK*1.8 + .30*np.sin(2*np.pi*108*_t)*np.exp(-_t/.065)
              + .10*np.sin(2*np.pi*1850*_t)*np.exp(-_t/.006))
_CLUB_KICK *= np.minimum(1,_t/.0015)


def groove(events, bars, seconds, festive=False, club=False, intro=True, natural=False, club_start_bar=None, hit_shape=None, refined_ending=False):
    count = round((seconds[-1]+2)*SR)
    drums, accompaniment = [np.zeros((count,2),dtype=np.float32) for _ in range(2)]
    voices = [[e for e in events if e['voice']==v] for v in range(3)]
    hits, pitched = [], []
    club_start = next(b['beat'] for b in bars if b['sourceBar']==club_start_bar) if club_start_bar is not None else 0
    def hit(kind, beat, velocity, pan=0):
        if kind=='technoKick' and beat<club_start:
            kind,velocity='kick',velocity*.30
        if hit_shape is not None:
            shaped=hit_shape(kind,beat,velocity,pan)
            if shaped is None:return
            kind,velocity,pan=shaped
        wave = (_CLUB_KICK if club else _TECHNO_KICK)*velocity if kind=='technoKick' else perc(kind,velocity)
        put(drums,float(seconds[round(beat*12)]),wave,pan)
        hits.append(dict(kind=kind,beat=beat,velocity=velocity))
    if festive and intro:
        # Twelve beats, like the Drac entrance: taiko, kit, then a pickup roll.
        for beat in range(12):
            level = .20+.018*beat
            hit('don' if beat%2==0 else 'ka',beat,level)
            if beat>=4:
                hit('technoKick' if club else 'kick',beat,.36 if club else .22)
                if beat%2:
                    hit('clap',beat,.17)
            for off in (0,.5):
                hit('shaker',beat+off,.12+.012*beat,.25)
        for i in range(8):
            hit('snare' if i%2 else 'tim',10+i/4,.10+.028*i,(-1)**i*.2)
        hit('crash',12,.23)
    # Strong taiko follows the written tune. Short subdivisions receive lighter ka.
    previous = None
    for e in voices[0]:
        if e['chord'] or (refined_ending and e['sourceBar']==92):
            continue
        strong = abs(e['beat']-round(e['beat'])) < 1e-8
        velocity = .34 if strong else .22
        if festive and e['sourceBar'] >= 9:
            velocity *= energy_at(e['sourceBar'],e['beat']%4) * 1.12
        elif 64 <= e['sourceBar'] <= 67:
            velocity *= .7
        if festive and fast_repeat(e,previous):
            velocity *= .45
        hit('don' if strong else 'ka',e['beat'],velocity)
        previous = e
    for bar in bars:
        number,start = bar['sourceBar'],bar['beat']
        if number == 92:
            hit('don',start,.65)
            hit('kick',start,.45)
            hit('crash',start,.22)
            if club:
                if refined_ending:
                    # Sixteenths on one timbal, not 32nds alternating low DONs.
                    # Start after the downbeat so it is not struck twice.
                    for i in range(1,12):
                        hit('tim',start+i/4,.10+.16*i/11,(-1)**i*.12)
                    hit('don',start+3,.50)
                    hit('technoKick',start+3,.50)
                    hit('crash',start+3,.20)
                else:
                    for i in range(24 if natural else 36):
                        hit('tim' if i%3 else 'don',start+i/(8 if natural else 12),.10+.22*i/(23 if natural else 35),(-1)**i*.2)
                    hit('don',start+3,.72)
                    hit('technoKick',start+3,.65)
                    hit('crash',start+3,.30)
            continue
        style = ('opening' if number<9 else 'final' if number>=84 else
                 'festa' if 31<=number<64 or number>=72 else 'dance')
        energy = .62 if 64<=number<=67 else .82 if 68<=number<=71 else 1
        if festive:
            energy = energy_at(number,0)
        local_lead = [e for e in voices[0] if e['occurrence']==bar['occurrence']]
        last_end = max(e['beat']+e['beats'] for e in local_lead)
        for kind,pattern in PATTERNS[style].items():
            for i,mark in enumerate(pattern):
                beat = start+i/4
                if mark == '.' or beat >= last_end-1e-8:
                    continue
                strength = energy_at(number,i/4) if festive else energy
                # Add subdivisions gradually: the very slow passage starts sparsely.
                if festive and 64<=number<=71:
                    progress = min(1,((number-64)*4+i/4)/30)
                    if (i%2 and progress<.5) or (kind in ('ohat','tim') and progress<.25):
                        continue
                lift = 1.35 if festive and kind in ('snare','clap','tamb','tim') else 1
                electronic = festive and kind=='kick' and ((9<=number<=62 or 72<=number<=91) if club else (35<=number<=62 or 72<=number<=91))
                instrument = 'technoKick' if electronic else kind
                velocity = LEVEL[kind]*strength*lift*(1 if mark=='x' else .55)
                hit(instrument,beat,velocity*((2.6 if club else 1.65) if electronic else 1),
                    -.22 if kind=='clap' else .25 if kind in ('shaker','tamb','tim') else 0)
        if number in (9,19,27,31,35,43,48,52,60,72,76,84):
            hit('crash',start,.22)
        if number in (34,42,59,83,90) or (festive and number in (30,51,71,75,79)):
            # A festive rising fill underneath the last written beat, not over a rest.
            for i in range(4):
                if start+3+i/4 < last_end:
                    hit('tim' if i%2 else 'snare',start+3+i/4,.12+i*.045,(-1)**i*.25)
        if festive and (31<=number<=62 or number>=72):
            for local in (1.5,3.5):
                if start+local<last_end:
                    hit('ka',start+local,.14*energy,-.3)
                    hit('tamb',start+local,.22*energy,.3)
        if club and number in (90,91):
            for i in range(16):
                hit('tim' if i%2 else 'don',start+i/4,.14+.20*i/15,(-1)**i*.22)
        if number < 9 or natural:
            continue
        for local in (.5,1.5,2.5,3.5):
            beat = start+local
            if beat >= last_end-1e-8:
                continue
            active = [[e for e in voice if e['beat']<=beat+1e-8 and
                       beat<e['beat']+e['beats']-1e-8] for voice in voices]
            lead = active[0]
            if not lead:
                continue
            energy = energy_at(number,local) if festive else energy
            at = float(seconds[round(beat*12)])
            # End each stab before any of its source voices changes pitch.
            for v in (1,2):
                for e in active[v]:
                    pitch = e['pitch']-(12 if v==2 else 0)
                    next_change = min([e['end'],*[n['end'] for n in lead]])
                    dur = min(.15,next_change-at)
                    if dur < .025 or any((pitch-n['pitch'])%12 in (1,11) for n in lead):
                        continue
                    if v == 1:
                        wave,t = brass(hz(pitch),dur)
                        wave *= adsr(t,dur,.009,min(.045,dur*.3),.3,.05)*(.0054 if club else .018 if festive else .065)*energy
                    else:
                        wave = nylon(hz(pitch),dur)*(.054 if club else .12 if festive else .23)*energy
                    put(accompaniment,at,note_gate(wave,dur),.4 if v==1 else -.35)
                    pitched.append(dict(beat=beat,pitch=pitch,sourceVoice=v,
                                        sourcePitch=e['pitch'],duration=dur))
    return drums,accompaniment,dict(hits=hits,pitched=pitched)
