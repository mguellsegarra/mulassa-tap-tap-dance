"""Explicit concert-to-game adaptation; written notes remain in bou-score.json."""

RANGES = ((1,16), (18,45), (47,92))
INTRO_BEATS = 12
OUTPUT = "output/bou-music/partitura-final-alt"
ENDING = {(91,2.0):79, (91,3.0):83, (92,0):84}  # G5, B5, C6: Marc-requested ascending ending.
ORDER = [bar for first,last in RANGES for bar in range(first,last+1)]
DESCRIPTION = 'Percussion 120→126; melodic intro 126→132; dance 126–136; bar 63 rit/fermata; 64–71 72→144; coda 144→150; final fermata at 75'


def select_score(score):
    return {**score, 'order': ORDER, 'form': 'Lluïment in written order, repeat passes omitted; percussion introduction'}


def tempo_at(bar, local):
    if bar < 9:
        return 126+6*((bar-1)*4+local)/32
    if 19 <= bar <= 26:
        return 126
    if bar < 31:
        return 132
    if bar < 63:
        return 136
    if bar == 63:
        return (136,110,68,72)[min(3,int(local))]
    if bar <= 71:
        return min(144,72+((bar-64)*4+local)*72/30)
    if bar < 84:
        return 144
    if bar < 92:
        return min(150,144+((bar-84)*4+local)*6/28)
    return 75


def energy_at(bar, local):
    """Continuous crescendo through the slow passage, independent of tempo."""
    if 64 <= bar <= 71:
        return .38 + .72 * min(1,((bar-64)*4+local)/30)
    if 72 <= bar < 84:
        return 1.10
    if bar >= 84:
        return 1.10 + .10 * min(1,((bar-84)*4+local)/28)
    return 1


def fast_repeat(event, previous):
    """A written sixteenth rearticulation, not a new decorative attack."""
    return (previous is not None and event['pitch']==previous['pitch']
            and event['beats']<=.25 and abs(event['start']-previous['end'])<1e-8)
