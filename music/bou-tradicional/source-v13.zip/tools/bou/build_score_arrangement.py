"""Render Bofarull's complete lluïment score with the game's shared warm timbres.

uv run --python 3.11 --with numpy --with scipy --with soundfile --with mido \
    python tools/bou/build_score_arrangement.py
No recording or estimated audio notes are mixed into these renders.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

import mido
import numpy as np
import soundfile as sf

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
from synth import SR, additive, adsr, hz, nylon, note_gate, perc, put
from score_groove import groove
import score_festive

OUT = ROOT / 'output/bou-music/partitura'
TRANSPOSE = 0  # Marc requests the written score only; no recording-derived transposition.
TICKS = 960
DIVISION = 12  # Exact thirds, quarters and eighths of a quarter-note beat.


def tempo_at(bar, local):
    if bar == 63:
        return [120, 105, 60, 80][min(3, int(local))]
    if 64 <= bar <= 71:
        return min(120, 60 + ((bar-64)*4 + local) * 60/30)
    if bar == 92:
        return 60  # Written fermata: hold the final whole note twice as long.
    return 120


def build_events(score, festive=False, intro_beats=None, tempo_fn=None, intro_end_bpm=126):
    tempo = tempo_fn or (score_festive.tempo_at if festive else tempo_at)
    intro = (score_festive.INTRO_BEATS if festive else 0) if intro_beats is None else intro_beats
    total = intro + len(score['order']) * 4
    tempos = np.array([(120+(intro_end_bpm-120)*b/intro) if b<intro else tempo(score['order'][int((b-intro)//4)], (b-intro)%4)
                       for b in (np.arange(total*DIVISION)+.5)/DIVISION])
    seconds = np.r_[0, np.cumsum(60 / tempos / DIVISION)]
    def at(beat):
        return float(seconds[round(beat*DIVISION)])
    events = []
    bars = []
    for index, number in enumerate(score['order']):
        start = intro+index*4
        bars.append(dict(sourceBar=number, occurrence=index+1, beat=start,
                         time=at(start), end=at(start+4)))
        for voice, notes in enumerate(score['bars'][number-1]['voices']):
            for n in notes:
                if n['pitch'] is None:
                    continue
                beat = start+n['beat']
                events.append(dict(voice=voice, sourceBar=number, occurrence=index+1,
                    beat=beat, beats=n['duration'], start=at(beat), end=at(beat+n['duration']),
                    writtenPitch=n['pitch'], pitch=(score_festive.ENDING.get((number,n['beat']),n['pitch'])
                        if festive and voice==0 else n['pitch'])+TRANSPOSE, chord=n['chord']))
    return events, bars, tempos, seconds


def write_midi(path, events, tempos, written=False, percussion=None):
    midi = mido.MidiFile(ticks_per_beat=TICKS)
    tempo_track = mido.MidiTrack()
    midi.tracks.append(tempo_track)
    tempo_track.append(mido.MetaMessage('time_signature', numerator=4, denominator=4))
    previous, previous_tempo = 0, None
    for i, bpm in enumerate(tempos):
        tempo = round(60e6/bpm)
        if tempo != previous_tempo:
            tick = i*TICKS//DIVISION
            tempo_track.append(mido.MetaMessage('set_tempo', tempo=tempo, time=tick-previous))
            previous, previous_tempo = tick, tempo
    for voice, name in enumerate(('Melodia', 'Segona veu', 'Baix escrit')):
        track = mido.MidiTrack()
        midi.tracks.append(track)
        track.append(mido.MetaMessage('track_name', name=name))
        track.append(mido.Message('program_change', channel=voice, program=[73,71,24][voice]))
        changes = []
        for n in events:
            if n['voice'] == voice:
                pitch = n['writtenPitch'] if written else n['pitch']
                changes += [(round(n['beat']*TICKS),1,pitch),
                            (round((n['beat']+n['beats'])*TICKS),0,pitch)]
        prev = 0
        for tick, on, pitch in sorted(changes):
            track.append(mido.Message('note_on' if on else 'note_off', channel=voice,
                                      note=pitch, velocity=([95,36,52][voice] if percussion is not None else 85) if on else 0, time=tick-prev))
            prev = tick
    if percussion is not None:
        track = mido.MidiTrack()
        midi.tracks.append(track)
        track.append(mido.MetaMessage('track_name',name='Percussio'))
        pitches = dict(don=41,ka=37,kick=36,technoKick=36,snare=38,clap=39,hat=42,ohat=46,shaker=70,tamb=54,tim=50,cowbell=56,crash=49)
        changes = []
        for e in percussion:
            tick = round(e['beat']*TICKS)
            pitch = pitches[e['kind']]
            velocity = max(1,min(127,round(e['velocity']*110)))
            changes.extend(((tick,1,pitch,velocity),(tick+TICKS//16,0,pitch,0)))
        previous = 0
        for tick,on,pitch,velocity in sorted(changes):
            track.append(mido.Message('note_on' if on else 'note_off',channel=9,note=pitch,velocity=velocity,time=tick-previous))
            previous = tick
    midi.save(path)


def write_xml(score, out=OUT):
    """Unfolded source in written pitch, with original bar references for score editors."""
    root = ET.Element('score-partwise', version='4.0')
    work = ET.SubElement(root,'work')
    ET.SubElement(work,'work-title').text = score['title']
    ident = ET.SubElement(root,'identification')
    ET.SubElement(ident,'creator',type='composer').text = score['composer']
    parts = ET.SubElement(root,'part-list')
    for v,name in enumerate(score['voices']):
        part = ET.SubElement(parts,'score-part',id=f'P{v+1}')
        ET.SubElement(part,'part-name').text = name
        dest = ET.SubElement(root,'part',id=f'P{v+1}')
        for k,number in enumerate(score['order']):
            bar = ET.SubElement(dest,'measure',number=str(k+1))
            if k == 0 or number == 31:
                attrs = ET.SubElement(bar,'attributes')
                ET.SubElement(attrs,'divisions').text = str(DIVISION)
                key = ET.SubElement(attrs,'key')
                ET.SubElement(key,'fifths').text = '-3' if number <31 else '0'
                time = ET.SubElement(attrs,'time')
                ET.SubElement(time,'beats').text = '4'
                ET.SubElement(time,'beat-type').text = '4'
                clef = ET.SubElement(attrs,'clef')
                ET.SubElement(clef,'sign').text = 'G'
                ET.SubElement(clef,'line').text = '2'
            direction = ET.SubElement(bar,'direction')
            dtype = ET.SubElement(direction,'direction-type')
            ET.SubElement(dtype,'words').text = f'Original: {number}'
            for e in score['bars'][number-1]['voices'][v]:
                note = ET.SubElement(bar,'note')
                if e['chord']:
                    ET.SubElement(note,'chord')
                if e['pitch'] is None:
                    ET.SubElement(note,'rest')
                else:
                    pitch = ET.SubElement(note,'pitch')
                    ET.SubElement(pitch,'step').text = e['name'][0]
                    alter = e['name'].count('#')-e['name'].count('b')
                    if alter:
                        ET.SubElement(pitch,'alter').text = str(alter)
                    ET.SubElement(pitch,'octave').text = e['name'][-1]
                ET.SubElement(note,'duration').text = str(round(e['duration']*DIVISION))
                if 'tuplet' in e:
                    mod = ET.SubElement(note,'time-modification')
                    ET.SubElement(mod,'actual-notes').text = '3'
                    ET.SubElement(mod,'normal-notes').text = '2'
            if k == len(score['order'])-1:
                line = ET.SubElement(bar,'barline',location='right')
                ET.SubElement(line,'bar-style').text = 'light-heavy'
    ET.indent(root)
    ET.ElementTree(root).write(out / 'bou-partitura.musicxml',encoding='utf-8',xml_declaration=True)


def dynamic(bar):
    if bar in (1,2,5,6): return .7
    if 39 <= bar <= 42 or 48 <= bar <= 51 or 56 <= bar <= 59 or 80 <= bar <= 83: return .78
    if 43 <= bar <= 47 or 60 <= bar <= 63 or bar >= 84: return 1.08
    return .9


def render_lead(events, count, soft_repeats=False, chord_gain=1):
    lead = np.zeros((count,2),dtype=np.float32)
    previous = None
    for e in events:
        if e['voice'] != 0:
            continue
        # Adding a count-in must not change the .5-second articulation branch.
        dur = round(e['end']-e['start'],9)
        # The written lower octave is support, not another full-strength lead.
        level = dynamic(e['sourceBar']) * (chord_gain if e['chord'] else 1)
        gate = dur * (.96 if dur < .5 else .985)
        for detune, pan, gain in ((0,0,1),(6,-.4,.22),(-6,.4,.22)):
            wave,t = additive(hz(e['pitch']),gate,1.3,.45,detune,.003 if dur>.4 else 0)
            env = adsr(t,gate,.008,min(.055,gate*.25),.82,.2)
            # The opening half notes grow into the following ff eighth.
            if e['sourceBar'] in (1,2,5,6) and e['beats'] == 2:
                env *= np.linspace(.55,1.1,len(env))
            put(lead,e['start'],wave*env*gain*.36*level,pan)
        pluck = .07 if soft_repeats and score_festive.fast_repeat(e,previous) else .17
        put(lead,e['start'],note_gate(nylon(hz(e['pitch']),dur),dur)*pluck*level,-.2)
        previous = e
    return lead


def render(events, bars, seconds, out=OUT, festive=False, club=False, intro=True, raw=False):
    n = round((seconds[-1]+2)*SR)
    lead = render_lead(events,n,soft_repeats=festive,chord_gain=.32 if club else 1)
    harmony, bass, low_bass = [np.zeros((n,2),dtype=np.float32) for _ in range(3)]
    drums, accompaniment, groove_events = groove(events,bars,seconds,festive=festive,club=club,intro=intro)
    for e in events:
        if e['voice'] == 0:
            continue
        dur = round(e['end']-e['start'],9)
        level = dynamic(e['sourceBar'])
        if e['voice'] == 1:
            gate = dur*.94
            wave,t = additive(hz(e['pitch']),gate,1.8,.7)
            put(harmony,e['start'],wave*adsr(t,gate,.018,min(.06,gate*.25),.72)*(.0042 if club else .014 if festive else .045)*level,.4)
        else:
            # Double the written bass one octave lower; no invented chord progression.
            put(bass,e['start'],nylon(hz(e['pitch']),dur*.94)*(.0117 if club else .039 if festive else .10)*level,-.18)
            pitch = e['pitch']-12
            gate = dur*.90
            wave,t = additive(hz(pitch),gate,2.2,1)
            put(low_bass,e['start'],wave*adsr(t,gate,.008,.06,.7)*(.054 if club else .12 if festive else .22)*level,-.08)
            put(low_bass,e['start'],nylon(hz(pitch),gate)*(.0612 if club else .136 if festive else .24)*level,-.18)
    mix = lead+harmony+bass+low_bass+drums+accompaniment
    for delay,gain in ((.041,.055),(.073,.04),(.109,.025)):
        shift = round(delay*SR)
        mix[shift:] += (lead[:-shift,::-1]+harmony[:-shift,::-1]) * gain
    if raw:
        levels = {name:float(np.sqrt(np.mean(stem.astype(np.float64)**2))) for name,stem in
                  [('lead',lead),('secondVoice',harmony),('writtenBass',bass),
                   ('lowBass',low_bass),('drums',drums),('accompaniment',accompaniment)]}
        return mix, groove_events, levels
    # Transparent peak normalization preserves the score's dynamic contrasts.
    gain = .89 / max(float(np.abs(mix).max()),1e-9)
    variants = [('bou-festiu',mix*gain),('bou-melodia',lead*gain),
                ('bou-tres-veus',(lead+harmony+bass)*gain)]
    stats = {}
    for name,audio in variants:
        assert np.isfinite(audio).all() and np.abs(audio).max() < 1
        sf.write(out/(name+'.wav'),audio,SR,subtype='PCM_24')
        subprocess.run(['ffmpeg','-v','error','-y','-i',str(out/(name+'.wav')),
            '-codec:a','libmp3lame','-b:a','192k',str(out/(name+'.mp3'))],check=True)
        stats[name] = dict(duration=len(audio)/SR,peak=float(np.abs(audio).max()),
                           sha256=hashlib.sha256((out/(name+'.mp3')).read_bytes()).hexdigest())
    rms = {name:float(np.sqrt(np.mean(stem.astype(np.float64)**2))) for name,stem in
           [('lead',lead),('secondVoice',harmony),('writtenBass',bass),
            ('lowBass',low_bass),('drums',drums),('accompaniment',accompaniment)]}
    (out/'mix-validation.json').write_text(json.dumps(dict(revision=6 if festive else 2,rms=rms,
        leadOverSecondVoiceDb=20*np.log10(rms['lead']/rms['secondVoice']),
        masterGain=gain,percussionHits=len(groove_events['hits']),
        accompanimentNotes=len(groove_events['pitched'])),indent=2)+'\n')
    (out/'groove.json').write_text(json.dumps(groove_events,indent=2)+'\n')
    return stats


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--festive', action='store_true', help='Render written order without repeat passes, with a percussion introduction')
    args = parser.parse_args()
    out = ROOT/score_festive.OUTPUT if args.festive else OUT
    out.mkdir(parents=True,exist_ok=True)
    score = json.loads((ROOT/'music/bou-score.json').read_text())
    if args.festive:
        score = score_festive.select_score(score)
    events,bars,tempos,seconds = build_events(score, festive=args.festive)
    write_midi(out/'bou-to-escrit.mid',events,tempos,written=True)
    write_xml(score, out)
    stats = render(events,bars,seconds,out,festive=args.festive)
    percussion = json.loads((out/'groove.json').read_text())['hits'] if args.festive else None
    write_midi(out/'bou-festiu.mid',events,tempos,percussion=percussion)
    manifest = dict(title=score['title'],sourceSha256=score['sourceSha256'],
        source='Bou-Tradicional.pdf',form=score['form'],transpose=TRANSPOSE,
        sourceBars=len(score['bars']),performedBars=len(bars),beats=len(seconds[::DIVISION])-1,
        introBeats=score_festive.INTRO_BEATS if args.festive else 0,melodyStart=bars[0]['time'],
        musicEnd=float(seconds[-1]),audio=stats,events=events,bars=bars,
        beatTimes=[float(s) for s in seconds[::DIVISION]],
        tempoInterpretation=score_festive.DESCRIPTION if args.festive else '120; bar 63 rit/fermata; 64–71 60→120; final fermata at 60',
        mixRevision=6 if args.festive else 2,
        sourcePolicy='Written phrase order; repeat passes omitted; percussion introduction; final three lead notes adapted at user request' if args.festive else
                     'Written score only; no audio-derived pitches, tempo or form',
        listeningVerified=False,gameIntegration=False)
    (out/'arrangement.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(notes=len(events),bars=len(bars),audio=stats),indent=2))


if __name__ == '__main__':
    main()
