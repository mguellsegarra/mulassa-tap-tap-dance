Extract into an empty directory. Run: uv run --python 3.11 --with numpy --with scipy --with soundfile --with mido python tools/bou/build_preferred.py
Outputs: output/bou-music/preferred/. ffmpeg required. The phrase-lab manifest contains only the frozen diagnostic stem gain.
